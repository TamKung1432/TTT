import { useState } from "react";
import "./App.css";

const phrases = [
  "ไม่",
  "เเน่ใจหรอ?",
  "เเน่ใจใช่มั้ย!?",
  "🥺",
  "ไม่ได้หรอคะ",
  "🥺🥺🥺",
  "Yes เหมือนกันเเค่คนละสี",
];

function App() {
  const [noCount, setNoCount] = useState(0);
  const [yesPressed, setYesPressed] = useState(false);
  const yesButtonSize = noCount * 20 + 16;

  function getNoButtonText() {
    return phrases[Math.min(noCount, phrases.length - 1)];
  }

  return (
    <div className="val-container">
      {" "}
      {yesPressed ? (
        <>
          <img
            src="https://media.tenor.com/gUiu1zyxfzYAAAAi/bear-kiss-bear-kisses.gif"
            alt="yes-pic"
          />
          <div className="val-text">
            เป็นเเฟนกันเเล้วนะคะ น่ารักมากเลยค่ะเจ้าเเจ้ม🤏🏻
          </div>
        </>
      ) : (
        <>
          <img
            src="https://media.tenor.com/vknNeIAWurIAAAAi/tkthao219-bear.gif"
            alt="bear-asking"
          />
          <div className="val-text">เป็นแฟนกันมั้ยคะ</div>
          <div>
            <button
              className="button yes-button"
              style={{ fontSize: yesButtonSize }}
              onClick={() => setYesPressed(true)}
            >
              Yes
            </button>
            <button
              onClick={() => setNoCount(noCount + 1)}
              className="button no-button"
            >
              {getNoButtonText()}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
export default App;
